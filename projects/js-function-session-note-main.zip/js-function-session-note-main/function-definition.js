function nameOfFunction() {
	// do stuff here
	console.log("Hey I am a function");
}

function sayHello(userName) {
	console.log("Hello " + userName);
	console.log("Hello " + userName);
	console.log("Hello " + userName);
	console.log("Hello " + userName);
	console.log("Hello " + userName);
	console.log("Hello " + userName);
	console.log("Hello " + userName);
	console.log("Hello " + userName);
	console.log("Hello " + userName);
}

function printUserInfo(fName, lName, age, country) {
	console.log(
		`My first name is ${fName} and my last name is ${lName} and I am ${age} years old. I come from ${country}.`,
	);
}

printUserInfo("Stephen", "Lagu", 55, "South Sudan");
