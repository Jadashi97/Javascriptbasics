// Object
// Attributes/properties - features, characteristics, fields;
// Behaviors - doing stuff;

class Phone {
	// Properties

	// Methods;
	ring(arg) {
		// ring;
	}
}

// Instance of Phone;
const iPhone = new Phone();
iPhone.ring();

// Instance of String;
const userName = "Daniel";
userName.toUpperCase();
